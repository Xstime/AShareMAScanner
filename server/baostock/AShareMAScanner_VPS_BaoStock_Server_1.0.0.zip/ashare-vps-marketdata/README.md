# AShareMAScanner VPS 行情服务 · BaoStock 版 1.0.0

这是**仅服务器端**程序，不包含桌面扫描器，也不会自行修改 GitHub Release、客户端或 VPS 上已有的服务配置。程序以 BaoStock 获取 A 股日线，在 VPS 维护 SQLite 数据库，并发布只读数据库快照供后续客户端更新功能下载。

## 运行计划

- 每天 **北京时间 18:00** 运行一次。systemd timer 使用 `10:00 UTC`，不修改 VPS 系统时区。
- 周末和节假日也会触发一次轻量检查；如果没有新交易日，不会重复下载已完成的日线。
- 首次运行建立最近 **80 个交易日**的历史缓存；后续只补新交易日和失败项。
- BaoStock 使用**单登录、单会话、串行请求**，不创建线程池/多进程。
- 每日 API 请求设置 45,000 次硬上限，低于 BaoStock 常见的 50,000 次/日限制；达到上限就停止并保留已完成数据。
- 连续 25 只股票请求失败会安全停止；失败股票使用 6、12、24、48、96、168 小时指数退避，避免每次定时任务反复撞接口。
- 行业分类默认 7 天刷新一次，失败时保留旧缓存。
- 只有最新交易日数据完整率和历史缓存覆盖率达到配置阈值（默认 99.5%）时才发布快照；否则保留上一份可下载快照，不把不完整数据冒充成功。

## BaoStock 黑名单风险

此前桌面端曾遇到 `10001011 黑名单用户`。这个服务会在登录时识别该错误并立即退出，不会无限循环登录或批量重试。**VPS 换了网络出口不代表一定能解除账号/IP 黑名单。**

安装后第一步必须运行 `probe`，确认 BaoStock 登录和最小交易日历查询成功，再启动首次全市场初始化。若仍返回 `10001011`，请先联系 BaoStock 管理方核查；不要反复运行全量任务。

## 数据兼容范围

快照中的核心表与 AShareMAScanner v1.3.7 兼容：

- `daily`：`code, trade_date, name, close, volume, trade_status, is_st, turnover`
- `day_universe`
- `day_status`
- `industry_cache`
- `server_meta`

价格为 BaoStock **后复权**（`adjustflag=1`），成交量按股，换手率按 BaoStock 返回值保留。客户端后续应将共享表导入独立的 BaoStock 本地库（建议 `a_share_baostock_hfq.db`），不要直接覆盖现有 AKShare 数据库，也不要覆盖本地 `signal_history`、资金 TOP5 缓存等客户端数据。

**同花顺五日资金流 TOP5 不在本服务中更新**：BaoStock 不提供与当前功能相同的资金流排名数据；该功能在客户端仍应沿用原数据来源。

## 目录结构

```text
ashare-vps-marketdata/
├── ashare_server/              # 更新器、BaoStock 适配器、SQLite、快照、只读 API
├── systemd/                    # 每日 18:00 定时器和 API 服务
├── nginx/marketdata.location.conf
├── tests/                      # 全部离线模拟测试
├── requirements.txt
├── .env.example
└── install.sh
```

## 安装到 Ubuntu VPS

解压后进入目录：

```bash
cd ashare-vps-marketdata
sudo bash install.sh
```

安装脚本会：

1. 创建无登录系统用户 `asharedata`。
2. 安装到 `/opt/ashare-marketdata`，数据库放在 `/var/lib/ashare-marketdata`。
3. 创建 Python 虚拟环境并安装 BaoStock、pandas。
4. 启动本地只读 API（`127.0.0.1:8765`）。
5. 安装每日 18:00（北京时间）的 systemd timer 单元，但**暂不启用 timer**。

安装脚本**不会自动启动首次全市场下载，也不会在 BaoStock 登录验证前启用定时任务**。先做 BaoStock 登录检查：

```bash
sudo -u asharedata /opt/ashare-marketdata/.venv/bin/python -m ashare_server.cli probe
```

probe 成功后，再手动启动首次建库：

```bash
sudo systemctl start ashare-market-update.service
```

确认首次快照已经生成后，启用每日 18:00 定时更新：

```bash
sudo systemctl enable --now ashare-market-update.timer
```

查看首次初始化进度：

```bash
journalctl -u ashare-market-update.service -f
```

查看当前数据库和待重试项目：

```bash
sudo -u asharedata /opt/ashare-marketdata/.venv/bin/python -m ashare_server.cli status
```

查看定时器：

```bash
systemctl list-timers ashare-market-update.timer
```

## HTTPS 下载接口

API 只监听 `127.0.0.1`，不直接暴露公网。把 `nginx/marketdata.location.conf` 中的 `location /marketdata/` 片段加入 VPS **现有 HTTPS server block**，不要覆盖原来的 `/ashare` 软件更新镜像路由。

然后编辑 `/etc/ashare-marketdata.env`：

```ini
ASHARE_PUBLIC_BASE_URL=https://你的域名/marketdata
```

重启 API：

```bash
sudo systemctl restart ashare-market-api.service
```

接口：

- `GET /marketdata/healthz`：服务健康状态
- `GET /marketdata/latest.json`：最新数据日期、完整率、文件大小、SHA-256、下载地址
- `GET /marketdata/snapshot.zip`：下载快照

该 API 是只读的，不提供远程触发采集或写入数据库的 HTTP 接口。

## 日志与故障排查

```bash
journalctl -u ashare-market-update.service --since today
journalctl -u ashare-market-api.service -f
```

- `10001011`：BaoStock 黑名单，任务快速失败；先核查账号/IP 状态。
- `安全请求上限`：当天请求达到 45,000 次，已停止；下个交易日继续。
- `连续 25 只股票请求失败`：保护性停止；检查 BaoStock 连通性和日志。
- `latest.json` 没有更新：检查完整率、失败队列及更新服务退出码。上一份快照会继续保留。

## 手动运行与测试

```bash
/opt/ashare-marketdata/.venv/bin/python -m ashare_server.cli update
/opt/ashare-marketdata/.venv/bin/python -m ashare_server.cli status
```

离线测试（不访问 BaoStock、不需要网络；当前交付共 12 项）：

```bash
python3 -m pip install -r requirements.txt
python3 -m unittest discover -s tests -v
```

## 当前交付边界

本包只完成 VPS 端采集、数据库和下载 API。尚未安装到你的 VPS，也尚未修改 v1.3.7 客户端去下载/合并该快照。下一阶段需要单独授权客户端改造与部署。首次 BaoStock `probe` 结果也必须在 VPS 上实测，当前离线测试不能替代真实登录验证。
